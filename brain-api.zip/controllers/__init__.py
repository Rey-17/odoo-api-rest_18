from . import auth_contoller
from . import sale_order_controller
from . import product_controller
from . import product_template_controller
from . import partner_controller
from . import sale_report_controller
from . import crm_lead_controller
from . import attachment_api